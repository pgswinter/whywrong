import {fetchDataConstants} from "../../_constant/fetchData.constants";

export function fetchRequestAction(){
    return{
        type: fetchDataConstants.REQUEST
    }
}