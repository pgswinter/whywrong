import { combineReducers } from 'redux';

import { fetchDataReducer } from './fetchData.reducers';

const rootReducer = combineReducers({
    fetchDataReducer
});

export default rootReducer;