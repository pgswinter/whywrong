import {fetchDataConstants} from "../../_constant/fetchData.constants";

const initialState = {}

export const fetchDataReducer = (state=initialState, action) => {
    let error;
    switch(action.type){
        case fetchDataConstants.REQUEST:
            return {...state, loading: true}
        case fetchDataConstants.SUCCESS:
            return {...state, payload: action.data, loading: false}
        case fetchDataConstants.FAILURE:
            return {...state, error: error, loading: false}
        default:
            return state
    }
}