import { connect } from 'react-redux';

const mapStateToProps = (state) => {
    console.log(state);
    return{
      data: state
    }
}

const Home = connect(mapStateToProps,null)(Home);
export default Home;