export const apiConstant = {
    api01: "https://demo2339618.mockable.io/"
}