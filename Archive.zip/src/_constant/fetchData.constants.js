export const fetchDataConstants = {
    REQUEST:"REQUEST",
    SUCCESS:"SUCCESS",
    FAILURE:"FAILURE"
}