import {call, put, takeLatest, all} from 'redux-saga/effects';
import {fetchDataService} from '../_services/fetchData.services';
import {fetchDataConstants} from '../_constant/fetchData.constants';

function* fetchDataSaga(){
    const {response, error} = fetchDataService;
    console.log(response)
    if(response){
        yield put({type: fetchDataConstants.SUCCESS,response});
    }else{
        yield put({type: fetchDataConstants.FAILURE, error});
    }
}

function* watcherData(){
    yield takeLatest(fetchDataConstants.REQUEST, fetchDataSaga);
}

function* rootSaga(){
    yield all([
        watcherData()
    ])
}

export default rootSaga