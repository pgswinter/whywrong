import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import { history } from './_helpers/history';
import { Router, Route, Switch } from "react-router-dom";
import Home from './_pages/Home';
import { Provider } from 'react-redux';

// import { createStore, applyMiddleware } from 'redux';
// import createSagaMiddleware from 'redux-saga';
// import { createLogger } from 'redux-logger';
// import rootReducer from './redux/reducers';

// const loggerMiddleware = createLogger();
// const sagaMiddleware = createSagaMiddleware();

// const store = createStore(
//   rootReducer,
//   applyMiddleware(
//       sagaMiddleware,
//       loggerMiddleware
//   )
// );
// sagaMiddleware.run(rootSaga);
import store from './_helpers/store';


class App extends Component {
  render() {
    return (
      <div className="App">
        <Provider store={store}>
          <Router history={history}>
          <div>
            <Route path="/" component={Home} />
          </div>
          </Router>
        </Provider>
      </div>
    );
  }
}

export default App;
