import {apiConstant} from '../_constant/apis.constants';

debugger
export const fetchDataService = () => 
    fetch(apiConstant.api01)
    .then((response) => {
        console.log(response);
        return response;
    })
    .catch((error) => ({error}));