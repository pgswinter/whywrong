import React from 'react';
// import Home from "../../_containers/home.container";
import {fetchRequestAction} from '../../redux/_actions/fetchData.actions';
import { connect } from 'react-redux';

class Home extends React.Component{
    componentDidMount(){
        this.props.fetchRequestAction();
    }
    render(){
        return <div>

        </div>
    }
}

const mapStateToProps = (state) => {
    console.log(state);
    return{
      data: state
    }
}
const mapDispatchToProps = {
    fetchRequestAction: fetchRequestAction
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);